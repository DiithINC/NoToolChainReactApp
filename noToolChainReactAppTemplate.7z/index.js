import App from "./app.js";

ReactDOM.render(
  React.createElement(App, null),
  document.getElementById("root")
);