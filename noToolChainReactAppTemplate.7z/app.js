
function App() {
    return React.createElement("p", null, "Hello, World!");
  }
  
  export default App;